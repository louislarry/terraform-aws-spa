// lambda-add-cors-to-stellar-toml
// @ts-check

const path = require("path");
const { STATUS_CODES } = require("http");

exports.handler = (event, context, callback) => {
  const { request, response } = event.Records[0].cf;
  const headers = response.headers;

  const isStellarToml = /stellar\.toml/.test(request.uri);

  if (isStellarToml) {
    headers["Access-Control-Allow-Origin"] = "*";
  }

  return callback(null, response);
};
